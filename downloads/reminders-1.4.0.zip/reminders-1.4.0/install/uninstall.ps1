# Removes Reminders installed by install.ps1. Shared data is kept unless -Purge is given.
# Needs admin rights (asks for them). Start uninstall.cmd from the unpacked distribution.
param([switch] $Purge, [switch] $Elevated)

. (Join-Path $PSScriptRoot 'common.ps1')

$principal = [Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $purgeArg = if ($Purge) { ' -Purge' } else { '' }
    Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList `
        "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Elevated$purgeArg"
    exit
}

try {
    foreach ($path in $Shortcuts) {
        if (Test-Path $path) { Remove-Item $path -Force }
    }
    # fails while some user still runs Reminders, the jars are locked
    foreach ($item in @($AppDir, $Launcher, (Join-Path $Root 'reminders.ico'))) {
        if (Test-Path $item) { Remove-Item $item -Recurse -Force }
    }
    if ($Purge) {
        Remove-Item $Root -Recurse -Force
        Write-Host 'Reminders removed including shared data'
    } else {
        Write-Host "Reminders removed, shared data kept in $Root (use -Purge to delete it)"
    }
} catch {
    Write-Host "Uninstallation failed, exit running Reminders of all users and try again: $_" -ForegroundColor Red
}
if ($Elevated) { Read-Host 'Press Enter to close' | Out-Null }
