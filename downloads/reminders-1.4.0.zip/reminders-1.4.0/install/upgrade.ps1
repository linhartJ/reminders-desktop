# Upgrades the existing installation to the version of the unpacked distribution, the shared data is kept.
# Needs no admin rights, any user of the computer can run it. Start upgrade.cmd from the unpacked distribution,
# -Force also allows installing an older version than the installed one.
param([switch] $Force)

. (Join-Path $PSScriptRoot 'common.ps1')

try {
    $version = Get-DistVersion
    $installed = Get-InstalledVersion
    if (-not $installed) { throw "Reminders is not installed in $Root, use install.cmd" }
    if ((Test-OlderVersion $version $installed) -and -not $Force) {
        throw "Installed version $installed is newer than $version, use -Force to downgrade"
    }

    Write-Host "Upgrading Reminders $installed to $version"
    Backup-Data $installed
    Install-Version $version
    Remove-OldVersions $version

    Write-Host 'Done. Running instances restart into the new version within a minute.'
} catch {
    Write-Host "Upgrade failed: $_" -ForegroundColor Red
    exit 1
}
