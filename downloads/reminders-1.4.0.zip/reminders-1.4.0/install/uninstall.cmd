@echo off
rem Runs uninstall.ps1 regardless of PowerShell execution policy, arguments are passed through.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1" %*
pause
