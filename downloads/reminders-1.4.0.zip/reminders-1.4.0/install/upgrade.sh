#!/bin/sh
# Upgrades the existing installation to the version of the unpacked distribution, the shared data is kept.
# Run from the unpacked distribution: sudo ./install/upgrade.sh [--force]
# --force also allows installing an older version than the installed one.
set -eu

. "$(dirname "$0")/common.sh"

require_root "[--force]"
locate_dist

INSTALLED=$(installed_version)
if [ -z "$INSTALLED" ]; then
    echo "Reminders is not installed in $APP_DIR, use install.sh" >&2
    exit 1
fi
if version_lt "$NEW_VERSION" "$INSTALLED" && [ "${1:-}" != "--force" ]; then
    echo "Installed version $INSTALLED is newer than $NEW_VERSION, use --force to downgrade" >&2
    exit 1
fi

echo "Upgrading Reminders $INSTALLED to $NEW_VERSION"
backup_data "$INSTALLED"
deploy
remove_old_versions

echo "Done. Running instances restart into the new version within a minute."
