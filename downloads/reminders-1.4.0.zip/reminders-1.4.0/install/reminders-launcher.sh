#!/bin/sh
# Starts Reminders with the database shared by all members of the "reminders" group.
# Installed as /usr/local/bin/reminders by install.sh.

APP_DIR=/opt/reminders
DATA_DIR=/var/lib/reminders
GROUP=reminders

# Local settings kept by upgrades, e.g. when Java is not installed from a package (java not on PATH):
#   export JAVA_HOME=/opt/jdk-25
[ -f /etc/default/reminders ] && . /etc/default/reminders

# Autostart entry is system-wide; start only for users sharing the data
id -nG | tr ' ' '\n' | grep -qx "$GROUP" || exit 0

# Keep created database and log files writable for the whole group
umask 0007

# Running instance watches the current version and restarts through this launcher when upgraded
VERSION=$(cat "$APP_DIR/current")
export REMINDERS_OPTS="-Dreminders.home=$DATA_DIR -Dreminders.version=$VERSION \
-Dreminders.currentVersionFile=$APP_DIR/current -Dreminders.launcher=/usr/local/bin/reminders"
exec "$APP_DIR/$VERSION/bin/reminders" "$@"
