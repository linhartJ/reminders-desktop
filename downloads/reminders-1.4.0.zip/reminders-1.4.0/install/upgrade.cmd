@echo off
rem Runs upgrade.ps1 regardless of PowerShell execution policy, arguments are passed through.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0upgrade.ps1" %*
pause
