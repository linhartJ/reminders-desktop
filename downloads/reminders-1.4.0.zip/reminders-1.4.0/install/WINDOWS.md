# Installing Reminders on Windows

This guide installs Reminders for all users of the computer. It starts automatically on login and all users share
one database: a reminder added by one user is visible to the others. Settings such as the note position and language
are personal. Installation needs administrator rights once, upgrades can be done by any user.

For Linux see [README.md](README.md).

## How it works

| What                       | Where                                                         |
|----------------------------|---------------------------------------------------------------|
| Application                | `C:\ProgramData\Reminders\app\<version>`, the started one named in `app\current` |
| Launcher                   | `C:\ProgramData\Reminders\reminders.cmd`                      |
| Start menu and autostart   | *Reminders* shortcuts for all users                           |
| Shared database and logs   | `C:\ProgramData\Reminders\data` and `logs`                    |
| Local settings (`JAVA_HOME`) | `C:\ProgramData\Reminders\config.cmd`                       |

- All users (the local *Users* group) may change everything in `C:\ProgramData\Reminders`. That is what lets them
  share the database and upgrade without administrator rights. It also means any user of the computer can change the
  application the others start, so install it only on a computer whose users trust each other.

## 1. Install Java 25

Reminders needs Java 25 or newer, e.g. [Eclipse Temurin](https://adoptium.net/) or Zulu. Let the Java installer add
Java to `PATH` (verify with `java -version` in a new command prompt). If it is not on `PATH`, create
`C:\ProgramData\Reminders\config.cmd` after the installation containing:

```bat
set "JAVA_HOME=C:\Program Files\Java\jdk-25"
```

## 2. Get the distribution

Build it with `gradlew distZip` (on Windows or Linux) and copy `build/distributions/reminders-<version>.zip` to the
computer. Unpack it anywhere, e.g. into *Downloads*.

## 3. Run the installer

Double-click `install\install.cmd` in the unpacked directory and confirm the administrator prompt. The installer:

1. creates `C:\ProgramData\Reminders` and allows all users to change it,
2. installs the application and the launcher,
3. creates the *Reminders* shortcut in the Start menu and in the Startup folder of all users.

Reminders then starts on every login, or start it now from the Start menu. The unpacked zip can be deleted
afterwards.

## Upgrading

Any user can upgrade, no administrator rights are needed: unpack the new distribution and double-click
`install\upgrade.cmd`. The shared data is kept.

The upgrade:

1. backs up the database to `C:\ProgramData\Reminders\backup\<date>-<previous version>` (the last 5 backups are kept),
2. installs the new version to `app\<new version>` next to the running one and makes it current,
3. removes previous versions no longer used by any running instance (the rest is removed by the next upgrade).

Running instances of all logged in users notice the new version within a minute and restart into it; while the
*Manage Reminders* or *Language setup* window is open, the restart waits until it is closed.

Installing an older version is refused; to allow it, run from a command prompt: `install\upgrade.cmd -Force`.

## Disabling autostart

The autostart shortcut is shared by all users. To disable it for everybody, delete *Reminders* from
`C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp` (needs administrator rights). A single user can
disable it in *Task Manager → Startup apps*.

## Uninstalling

Exit Reminders for all logged in users, then double-click `install\uninstall.cmd`, or to delete the shared data too
run from a command prompt: `install\uninstall.cmd -Purge`.

## Troubleshooting

- **Nothing starts** – run `C:\ProgramData\Reminders\reminders.cmd` from a command prompt. *Windows cannot find
  'javaw.exe'* means Java is not on `PATH`, see step 1.
- **Logs** – `C:\ProgramData\Reminders\logs\server.log` and `error.log`.
- **Restoring a backup** – exit Reminders for all users and copy the `data` directory of the backup to
  `C:\ProgramData\Reminders`.
