# Shared by install.sh and upgrade.sh, sourced from them.
#
# Every version is installed into its own directory /opt/reminders/<version>, /opt/reminders/current names the one
# started by the launcher. Running instances notice the change of current and restart into the new version, so the
# upgrade does not have to stop instances of logged in users. Directories of old versions are removed once no
# instance uses them.

APP_DIR=/opt/reminders
DATA_DIR=/var/lib/reminders
GROUP=reminders
LAUNCHER=/usr/local/bin/reminders
# local settings of the launcher (e.g. JAVA_HOME), kept by upgrades
CONFIG=/etc/default/reminders
# number of database backups kept by upgrades
BACKUPS_KEPT=5

require_root() {
    if [ "$(id -u)" -ne 0 ]; then
        echo "Run as root: sudo $0 $1" >&2
        exit 1
    fi
}

# Sets SCRIPT_DIR, DIST_DIR and NEW_VERSION of the unpacked distribution this script runs from
locate_dist() {
    SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
    DIST_DIR=$(dirname "$SCRIPT_DIR")
    if [ ! -f "$DIST_DIR/VERSION" ] || [ ! -f "$DIST_DIR/bin/reminders" ] || [ ! -d "$DIST_DIR/lib" ]; then
        echo "Distribution not found in $DIST_DIR, run the script from the unpacked zip" >&2
        exit 1
    fi
    NEW_VERSION=$(cat "$DIST_DIR/VERSION")
}

# Version of the existing installation, empty when not installed
installed_version() {
    if [ -f "$APP_DIR/current" ]; then
        cat "$APP_DIR/current"
    elif [ -d "$APP_DIR/lib" ]; then
        # layout before 1.4.0: application directly in /opt/reminders
        for jar in "$APP_DIR"/lib/reminders-*.jar; do
            if [ -f "$jar" ]; then
                basename "$jar" .jar | sed 's/^reminders-//'
            fi
        done
    fi
}

# True when the first version is older than the second one
version_lt() {
    [ "$1" != "$2" ] && [ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | head -n 1)" = "$1" ]
}

# True when a running instance uses the application directory
in_use() {
    pgrep -f -- "$1/lib/" >/dev/null 2>&1
}

# Launcher before 1.4.0 was edited to set JAVA_HOME, the setting moves to the config file
preserve_java_home() {
    if [ ! -f "$CONFIG" ] && [ -f "$LAUNCHER" ] && grep -q '^export JAVA_HOME=' "$LAUNCHER"; then
        echo "Moving JAVA_HOME setting from $LAUNCHER to $CONFIG"
        grep '^export JAVA_HOME=' "$LAUNCHER" > "$CONFIG"
        chmod 644 "$CONFIG"
    fi
}

backup_data() {
    [ -d "$DATA_DIR/data" ] || return 0
    backup="$DATA_DIR/backup/$(date +%Y%m%d-%H%M%S)-$1"
    echo "Backing up database to $backup"
    mkdir -p "$backup"
    cp -a "$DATA_DIR/data" "$backup/"
    ls -1d "$DATA_DIR"/backup/*/ | head -n -"$BACKUPS_KEPT" | while read -r old; do rm -rf "$old"; done
}

# Installs the distribution as the new current version together with launcher and desktop entries
deploy() {
    target="$APP_DIR/$NEW_VERSION"
    echo "Installing application version $NEW_VERSION to $target"
    mkdir -p "$APP_DIR"
    if [ -d "$target" ] && in_use "$target"; then
        echo "Version $NEW_VERSION is already installed and running, keeping its files"
    else
        rm -rf "$target" "$target.tmp"
        mkdir "$target.tmp"
        cp -r "$DIST_DIR/bin" "$DIST_DIR/lib" "$target.tmp/"
        chmod 755 "$target.tmp/bin/reminders"
        mv "$target.tmp" "$target"
    fi
    install -m 644 "$SCRIPT_DIR/reminders.png" "$APP_DIR/reminders.png"

    preserve_java_home
    install -m 755 "$SCRIPT_DIR/reminders-launcher.sh" "$LAUNCHER"
    install -m 644 "$SCRIPT_DIR/reminders.desktop" /usr/share/applications/reminders.desktop
    install -m 644 "$SCRIPT_DIR/reminders.desktop" /etc/xdg/autostart/reminders.desktop

    # replaced in one step, running instances never read a partially written file
    printf '%s\n' "$NEW_VERSION" > "$APP_DIR/current.tmp"
    chmod 644 "$APP_DIR/current.tmp"
    mv "$APP_DIR/current.tmp" "$APP_DIR/current"
}

# Removes directories of previous versions that no running instance uses any more
remove_old_versions() {
    for dir in "$APP_DIR"/*/; do
        dir=${dir%/}
        [ "$(basename "$dir")" = "$NEW_VERSION" ] && continue
        [ -d "$dir/lib" ] || continue
        if in_use "$dir"; then
            echo "Keeping $dir, still in use until running instances restart (removed by the next upgrade)"
        else
            rm -rf "$dir"
        fi
    done
    if [ -d "$APP_DIR/lib" ]; then
        if in_use "$APP_DIR"; then
            echo "Previous version is still running for some users. It does not restart by itself:" \
                 "choose Exit in its menu and start Reminders again, or log out and in." \
                 "Run the upgrade once more afterwards to remove its files."
        else
            rm -rf "$APP_DIR/bin" "$APP_DIR/lib"
        fi
    fi
}
