@echo off
rem Runs install.ps1 regardless of PowerShell execution policy, arguments are passed through.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
pause
