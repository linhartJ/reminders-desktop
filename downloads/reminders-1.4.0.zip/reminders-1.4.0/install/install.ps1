# Installs Reminders for all users of this computer, started on login, sharing one database.
# Needs admin rights (asks for them), later upgrades do not. Running it again reinstalls the application,
# the shared data is kept. Start install.cmd from the unpacked distribution, see WINDOWS.md.
param([switch] $Elevated)

. (Join-Path $PSScriptRoot 'common.ps1')

$principal = [Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList `
        "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Elevated"
    exit
}

# Shortcut needs an .ico, Windows accepts a PNG image stored in it
function Write-Icon([string] $Png, [string] $Ico) {
    $image = [IO.File]::ReadAllBytes($Png)
    $stream = New-Object IO.MemoryStream
    $writer = New-Object IO.BinaryWriter($stream)
    $writer.Write([uint16] 0); $writer.Write([uint16] 1); $writer.Write([uint16] 1)
    # width and height are the lowest bytes of the big-endian values in PNG header
    $writer.Write([byte] $image[19]); $writer.Write([byte] $image[23]); $writer.Write([byte] 0); $writer.Write([byte] 0)
    $writer.Write([uint16] 1); $writer.Write([uint16] 32); $writer.Write([uint32] $image.Length); $writer.Write([uint32] 22)
    $writer.Write($image)
    $writer.Flush()
    [IO.File]::WriteAllBytes($Ico, $stream.ToArray())
}

try {
    $version = Get-DistVersion

    if (-not (Get-Command javaw.exe -ErrorAction SilentlyContinue)) {
        Write-Warning "javaw.exe not found on PATH, install Java 25 or set JAVA_HOME in $Root\config.cmd"
    }

    Write-Host "Preparing shared directory $Root"
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    # all users (local group Users) may change the data and upgrade the application
    icacls $Root /grant '*S-1-5-32-545:(OI)(CI)M' | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Setting permissions of $Root failed" }

    Install-Version $version
    Remove-OldVersions $version

    Write-Host 'Installing Start menu and autostart shortcuts for all users'
    $icon = Join-Path $Root 'reminders.ico'
    Write-Icon (Join-Path $PSScriptRoot 'reminders.png') $icon
    $shell = New-Object -ComObject WScript.Shell
    foreach ($path in $Shortcuts) {
        $shortcut = $shell.CreateShortcut($path)
        $shortcut.TargetPath = $Launcher
        $shortcut.WorkingDirectory = $Root
        $shortcut.IconLocation = $icon
        # minimized: launcher console window only flashes in the taskbar
        $shortcut.WindowStyle = 7
        $shortcut.Save()
    }

    Write-Host 'Done. Reminders starts on next login, or start it now from the Start menu.'
} catch {
    Write-Host "Installation failed: $_" -ForegroundColor Red
}
if ($Elevated) { Read-Host 'Press Enter to close' | Out-Null }
