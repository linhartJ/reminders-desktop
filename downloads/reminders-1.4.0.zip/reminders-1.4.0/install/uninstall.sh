#!/bin/sh
# Removes Reminders installed by install.sh. Shared data is kept unless --purge is given.
set -eu

. "$(dirname "$0")/common.sh"

require_root "[--purge]"

rm -rf "$APP_DIR"
rm -f "$LAUNCHER" "$CONFIG" /usr/share/applications/reminders.desktop /etc/xdg/autostart/reminders.desktop

if [ "${1:-}" = "--purge" ]; then
    rm -rf "$DATA_DIR"
    getent group "$GROUP" >/dev/null && groupdel "$GROUP"
    echo "Reminders removed including shared data and group $GROUP"
else
    echo "Reminders removed, shared data kept in $DATA_DIR (use --purge to delete it)"
fi
