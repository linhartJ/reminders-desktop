# Installing Reminders on Linux Mint (MATE)

For Windows see [WINDOWS.md](WINDOWS.md).

This guide installs Reminders for all users on the computer (here `jli` and `kli`). It starts automatically on
login and both users share one database: a reminder added by one user is visible to the other. Settings such as
the note position and language are personal.

## How it works

| What                       | Where                                   |
|----------------------------|-----------------------------------------|
| Application                | `/opt/reminders/<version>`, the started one named in `/opt/reminders/current` |
| Launcher                   | `/usr/local/bin/reminders`              |
| Autostart entry            | `/etc/xdg/autostart/reminders.desktop`  |
| Applications menu entry    | `/usr/share/applications/reminders.desktop` |
| Shared database and logs   | `/var/lib/reminders`                    |
| Local settings (`JAVA_HOME`) | `/etc/default/reminders`              |

- Users who share the data are members of the `reminders` group. The data directory belongs to this group and has
  the setgid bit set, and the launcher sets `umask 0007`, so files created by either user stay writable for both.
- The autostart entry applies to every account, but the launcher starts the app only for members of the
  `reminders` group. Other accounts on the computer are not affected.
- The autostart is delayed by 10 seconds so the MATE panel is ready to show the tray icon.

## 1. Install Java 25

Reminders needs Java 25 or newer, the full runtime (not `headless`).

Check whether your Mint release offers it:

```sh
apt-cache policy openjdk-25-jre
```

If a candidate version is listed, install it:

```sh
sudo apt install openjdk-25-jre
```

Otherwise install Eclipse Temurin from the Adoptium repository:

```sh
sudo apt install -y wget gpg
wget -qO - https://packages.adoptium.net/artifactory/api/gpg/key/public \
    | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/adoptium.gpg > /dev/null
echo "deb https://packages.adoptium.net/artifactory/deb $(awk -F= '/^UBUNTU_CODENAME/{print $2}' /etc/os-release) main" \
    | sudo tee /etc/apt/sources.list.d/adoptium.list
sudo apt update
sudo apt install temurin-25-jre
```

Verify with `java -version`.

## 2. Get the distribution

Either build it on any computer with JDK 25 (Windows works too, the zip contains everything for Linux):

```sh
./gradlew distZip
```

and copy `build/distributions/reminders-<version>.zip` to the Mint computer, or build it directly on Mint after
installing `openjdk-25-jdk` / `temurin-25-jdk` instead of the JRE.

Unpack it anywhere, e.g. into your home directory:

```sh
cd ~
unzip reminders-1.4.0.zip
```

## 3. Run the installer

```sh
sudo sh ~/reminders-1.4.0/install/install.sh jli kli
```

The installer:

1. creates the `reminders` group and adds `jli` and `kli` to it,
2. copies the application to `/opt/reminders` and the launcher to `/usr/local/bin/reminders`,
3. installs the menu entry and the autostart entry,
4. creates the shared data directory `/var/lib/reminders`.

The unpacked zip can be deleted afterwards.

## 4. Log out and back in

Group membership is applied on login, so **both users have to log out and log in again** (or restart the
computer). After that Reminders starts automatically. It can also be started from the menu:
*Menu → Accessories → Reminders*.

## Daily use

- The note shows upcoming reminders. Drag it by the title bar to move it.
- Right-click the note (or the tray icon) for *Language setup*, *Manage Reminders* and *Exit*.
- If there is nothing to remind and the tray icon is not available, the note shows *No upcoming reminders* so the
  menu stays reachable.

### Both users at once

Reminders can run for both users at the same time, e.g. when switching users with *Switch User*. The database is
opened only for the moment of reading or saving, so neither instance blocks the other.

A reminder added by one user appears on the other user's note at the next refresh, which happens every hour and
whenever that user changes something themselves (adds or imports reminders, changes settings).

### Personal settings

Reminders are shared, but each user has their own settings: note position, language, and birthday settings
(how many days in advance and the message template).

## Disabling autostart for one user

Open *Startup Applications* (Menu → Control Center → Personal) and uncheck *Reminders*. This affects only the
current user. To exclude a user completely, remove them from the group: `sudo gpasswd -d kli reminders`.

## Upgrading

Unpack the new distribution and run the upgrade script. No users need to be given, the shared data in
`/var/lib/reminders` is kept.

```sh
cd ~
unzip reminders-<new version>.zip
sudo sh ~/reminders-<new version>/install/upgrade.sh
```

The upgrade:

1. backs up the database to `/var/lib/reminders/backup/<date>-<previous version>` (the last 5 backups are kept),
2. installs the new version to `/opt/reminders/<new version>` next to the running one and makes it current,
3. removes previous versions no longer used by any running instance (the rest is removed by the next upgrade).

Running instances of all logged in users notice the new version within a minute and restart into it; while the
*Manage Reminders* or *Language setup* window is open, the restart waits until it is closed.

Installing an older version is refused, `upgrade.sh --force` allows it.

### Upgrading from 1.3.0 or older

Older versions were installed directly in `/opt/reminders`; `upgrade.sh` converts the installation to the new layout
and moves a `JAVA_HOME` set in `/usr/local/bin/reminders` to `/etc/default/reminders`. Older versions do not restart
by themselves: each user has to choose *Exit* and start Reminders again from the menu (or log out and in). Their
files are removed by the next upgrade, or by running `upgrade.sh` again once nobody runs the old version.

## Uninstalling

```sh
sudo sh /path/to/reminders-<version>/install/uninstall.sh          # keeps the data
sudo sh /path/to/reminders-<version>/install/uninstall.sh --purge  # also deletes the data and the group
```

## Troubleshooting

- **Nothing starts after login** – check the group with `id` (must list `reminders`; log out and in after
  installation) and start the launcher from a terminal to see errors: `/usr/local/bin/reminders`.
- **`java` not found** – Java is not installed from a package. Create `/etc/default/reminders` containing
  `export JAVA_HOME=/path/to/jdk-25`; upgrades keep this file.
- **Logs** – `/var/lib/reminders/logs/server.log` and `error.log`.
- **No tray icon** – start the app later than the panel by increasing `X-MATE-Autostart-Delay` in
  `/etc/xdg/autostart/reminders.desktop`. The right-click menu on the note works regardless.
- **Backup** – use *Manage Reminders → Export*, or copy `/var/lib/reminders/data` while the app is not running.
  Upgrades back up the database to `/var/lib/reminders/backup`; to restore one, exit Reminders for all users and
  copy its `data` directory back.
