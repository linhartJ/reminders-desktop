# Shared by install.ps1, upgrade.ps1 and uninstall.ps1, dot-sourced from them.
#
# Every version is installed into its own directory app\<version>, app\current names the one started by the launcher.
# Running instances notice the change of current and restart into the new version, so the upgrade does not have
# to stop instances of other logged in users (which would require admin rights). Directories of old versions are
# removed once no instance uses them.

$ErrorActionPreference = 'Stop'

# REMINDERS_ROOT changes the installation directory, meant for testing the scripts
$Root = if ($env:REMINDERS_ROOT) { $env:REMINDERS_ROOT } else { Join-Path $env:ProgramData 'Reminders' }
$AppDir = Join-Path $Root 'app'
$CurrentFile = Join-Path $AppDir 'current'
$Launcher = Join-Path $Root 'reminders.cmd'
$StartMenuDir = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'
$Shortcuts = @((Join-Path $StartMenuDir 'Reminders.lnk'), (Join-Path $StartMenuDir 'StartUp\Reminders.lnk'))
# number of database backups kept by upgrades
$BackupsKept = 5

$DistDir = Split-Path -Parent $PSScriptRoot

function Get-DistVersion {
    $versionFile = Join-Path $DistDir 'VERSION'
    if (-not (Test-Path $versionFile) -or -not (Test-Path (Join-Path $DistDir 'lib'))) {
        throw "Distribution not found in $DistDir, run the script from the unpacked zip"
    }
    (Get-Content $versionFile -Raw).Trim()
}

# Version of the existing installation, $null when not installed
function Get-InstalledVersion {
    if (Test-Path $CurrentFile) { (Get-Content $CurrentFile -Raw).Trim() } else { $null }
}

# True when the first version is older than the second one
function Test-OlderVersion([string] $Version, [string] $Than) {
    try {
        [version] $Version -lt [version] $Than
    } catch {
        # not a plain numeric version (e.g. SNAPSHOT), do not block
        $false
    }
}

# Removes the directory unless a running instance uses it. Windows does not allow renaming a directory with an open
# file (jar of a running instance) inside, even for processes of other users, so the rename is the test.
function Remove-UnusedDirectory([string] $Dir) {
    $doomed = "$Dir.delete"
    if ($Dir -ne $doomed -and (Test-Path $doomed)) { Remove-Item $doomed -Recurse -Force }
    try {
        [IO.Directory]::Move($Dir, $doomed)
    } catch {
        return $false
    }
    Remove-Item $doomed -Recurse -Force
    $true
}

function Backup-Data([string] $InstalledVersion) {
    $data = Join-Path $Root 'data'
    if (-not (Test-Path $data)) { return }
    $backupDir = Join-Path $Root 'backup'
    $backup = Join-Path $backupDir ("{0:yyyyMMdd-HHmmss}-{1}" -f (Get-Date), $InstalledVersion)
    Write-Host "Backing up database to $backup"
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    Copy-Item $data $backup -Recurse
    Get-ChildItem $backupDir -Directory | Sort-Object Name -Descending | Select-Object -Skip $BackupsKept |
        Remove-Item -Recurse -Force
}

# Installs the distribution as the new current version together with the launcher
function Install-Version([string] $Version) {
    $target = Join-Path $AppDir $Version
    Write-Host "Installing application version $Version to $target"
    New-Item -ItemType Directory -Path $AppDir -Force | Out-Null
    if ((Test-Path $target) -and -not (Remove-UnusedDirectory $target)) {
        Write-Host "Version $Version is already installed and running, keeping its files"
    } else {
        $tmp = "$target.tmp"
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        New-Item -ItemType Directory -Path $tmp | Out-Null
        # launcher builds the classpath itself, bin is not needed
        Copy-Item (Join-Path $DistDir 'lib') $tmp -Recurse
        Rename-Item $tmp $Version
    }
    Copy-Item (Join-Path $PSScriptRoot 'reminders.cmd') $Launcher -Force

    # replaced in one step, running instances never read a partially written file
    $tmpCurrent = "$CurrentFile.tmp"
    [IO.File]::WriteAllText($tmpCurrent, $Version)
    if (Test-Path $CurrentFile) {
        # PowerShell would pass $null as empty string, which is not a valid path
        [IO.File]::Replace($tmpCurrent, $CurrentFile, [NullString]::Value)
    } else {
        [IO.File]::Move($tmpCurrent, $CurrentFile)
    }
}

# Removes directories of previous versions that no running instance uses any more
function Remove-OldVersions([string] $Version) {
    Get-ChildItem $AppDir -Directory | Where-Object { $_.Name -ne $Version } | ForEach-Object {
        if (-not (Remove-UnusedDirectory $_.FullName)) {
            Write-Host "Keeping $($_.FullName), still in use until running instances restart (removed by the next upgrade)"
        }
    }
}
