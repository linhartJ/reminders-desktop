#!/bin/sh
# Installs Reminders system-wide, started on login for given users who share one database.
# Run from the unpacked distribution: sudo ./install/install.sh jli kli
# Running it again adds users and reinstalls the application, the shared data is kept.
set -eu

. "$(dirname "$0")/common.sh"

require_root "USER [USER...]"
if [ $# -eq 0 ]; then
    echo "Usage: sudo $0 USER [USER...]" >&2
    exit 1
fi
locate_dist

for user in "$@"; do
    id "$user" >/dev/null 2>&1 || { echo "Unknown user: $user" >&2; exit 1; }
done

command -v java >/dev/null 2>&1 \
    || echo "Warning: java not found on PATH, install Java 25 or set JAVA_HOME in $CONFIG" >&2

echo "Creating group $GROUP and adding users: $*"
getent group "$GROUP" >/dev/null || groupadd --system "$GROUP"
for user in "$@"; do
    usermod -aG "$GROUP" "$user"
done

echo "Preparing shared data directory $DATA_DIR"
# setgid: files and directories created inside stay owned by the group
mkdir -p "$DATA_DIR"
chgrp -R "$GROUP" "$DATA_DIR"
chmod 2770 "$DATA_DIR"
chmod -R g+rwX "$DATA_DIR"

deploy
remove_old_versions

echo "Done. Users must log out and back in to pick up the new group membership."
