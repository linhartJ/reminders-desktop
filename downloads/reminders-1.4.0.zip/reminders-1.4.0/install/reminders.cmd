@echo off
rem Starts Reminders with the database shared by all users of this computer.
rem Installed to %ProgramData%\Reminders by install.ps1, see WINDOWS.md.
setlocal
set "ROOT=%~dp0"
set "ROOT=%ROOT:~0,-1%"

rem Local settings kept by upgrades, e.g. when Java is not on PATH create config.cmd containing:
rem   set "JAVA_HOME=C:\Program Files\Java\jdk-25"
if exist "%ROOT%\config.cmd" call "%ROOT%\config.cmd"

set "JAVAW=javaw.exe"
if defined JAVA_HOME set "JAVAW=%JAVA_HOME%\bin\javaw.exe"

rem Running instance watches the current version and restarts through this launcher when upgraded
set /p VERSION=<"%ROOT%\app\current"
start "" "%JAVAW%" --enable-native-access=ALL-UNNAMED "-Dreminders.home=%ROOT%" "-Dreminders.version=%VERSION%" ^
    "-Dreminders.currentVersionFile=%ROOT%\app\current" "-Dreminders.launcher=%~f0" ^
    -cp "%ROOT%\app\%VERSION%\lib\*" cz.jlinhart.reminders.RemindersApplicationKt %*
